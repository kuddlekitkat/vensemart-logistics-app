//
//  PayTabs.h
//  PayTabs
//
//  Created by Mohamed Adly on 10/11/20.
//

#import <Foundation/Foundation.h>
